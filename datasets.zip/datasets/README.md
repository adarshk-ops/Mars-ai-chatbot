# MarsMind starter datasets

This folder contains a starter Mars knowledge corpus and supervised question-answer examples based on NASA material reviewed on 2026-10-27.

## Files

- `mars_knowledge.jsonl`: 26 topic-organized source-grounded knowledge records.
- `mars_knowledge_supplement.jsonl`: 66 additional source-grounded records from 11 further NASA pages; IDs use the `mars_supp_` prefix.
- `mars_qa_train.jsonl`: 32 supervised examples.
- `mars_qa_validation.jsonl`: 7 examples for validation.
- `mars_qa_test.jsonl`: 7 held-out evaluation examples.
- `mars_sources.csv`: 13 source records and provenance notes.
- `dataset_quality_report.md`: counts, checks, review flags, and limitations.

JSONL files use one JSON object per line. QA records include two conversational messages (`user`, then `assistant`), a topic, source title, URL, and `source_page: null`. The additional `source_section` and `source_document_id` fields preserve provenance. Source metadata is outside the conversational message text.

## Provenance and limits

The knowledge records are concise cleaned summaries of the listed source pages, not complete document extractions. Their text preserves important qualifications and context, but users should consult the linked source before relying on an individual claim. No NASA Planetary Data System archive or peer-reviewed article was independently downloaded and analyzed for this starter set. Several NASA pages summarize research rather than reproduce the primary paper.

The source URLs were accessible during preparation. A null publication date means that the page did not provide a clear date in the reviewed material; it does not mean the page is undated in every version. Dynamic mission-status pages can change. See the quality report for review flags, including the reported 2025 potential-biosignature result and source-specific water claims.

## Python loading

```python
import json

def load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

knowledge = load_jsonl("mars_knowledge.jsonl")
train = load_jsonl("mars_qa_train.jsonl")
validation = load_jsonl("mars_qa_validation.jsonl")
test = load_jsonl("mars_qa_test.jsonl")
```

Keep each knowledge record's document ID and source fields attached when chunking for RAG. Copy provenance fields to every derived chunk; avoid concatenating citations into scientific text unless the RAG framework requires it.

For supervised fine-tuning, preserve source metadata separately from the conversation. Convert `messages` to the selected Gemma model's supported chat template using the matching Transformers/TRL tooling. Validate the final formatted data against the chosen model version before training. Do not train on validation or test examples. The provided split is a small starter split; for larger revisions, deduplicate and group semantic near-duplicates before splitting so related variants stay in one partition. Consider a fixed random seed and save the split manifest for reproducibility.

## Suggested revision workflow

1. Add and review source documents before generating new examples.
2. Record publication/retrieval dates and exact page or section references where possible.
3. Update knowledge records without collapsing source-specific differences.
4. Generate QA pairs only from reviewed records, then run duplicate, support, unit/date, and split-leakage checks.
5. Preserve a versioned source list and document any records that need scientific review.
