# MarsMind dataset quality report

Prepared: 2026-10-27

## Counts

| Item | Count |
|---|---:|
| Knowledge records | 26 |
| QA examples | 46 |
| Training | 32 |
| Validation | 7 |
| Held-out test | 7 |
| QA records with source URL/title and accessible source attribution checked | 46 |
| Exact duplicate question groups found across splits | 0 |
| Candidate near-duplicate questions found in manual review | 0 |
| Records flagged for human review | 5 knowledge records; 6 QA examples |

The source attribution count means every QA example points to a NASA source page that was accessible and reviewed during this preparation. It does not mean each claim was independently checked against a primary research paper or raw mission data. `source_page` is null because the HTML pages do not have stable page numbers; section headings are stored separately.

## Additional knowledge supplement

The separate `mars_knowledge_supplement.jsonl` file adds 66 records from 11 additional NASA pages, covering MRO, InSight, Mars Odyssey, Mars Global Surveyor, Spirit and Opportunity, MOXIE, MAVEN, ESCAPADE, and further Perseverance findings. All 66 lines parsed as JSON, required provenance fields were present, document IDs were unique, and no exact text duplicates matched the original 26-record knowledge file. The supplement is not included in the QA split statistics above. Several mission-status statements and interpretations remain time-sensitive and need source review before use.

## QA topic distribution

| Topic | Count |
|---|---:|
| Atmosphere and Climate | 4 |
| Curiosity Discoveries | 2 |
| Earth Comparison | 3 |
| Exploration Missions | 4 |
| Habitability and Life | 4 |
| Human Exploration | 5 |
| Introduction | 1 |
| Moons | 3 |
| Orbit and Rotation | 3 |
| Perseverance Discoveries | 3 |
| Physical Characteristics | 2 |
| Surface and Geology | 4 |
| Terraforming | 3 |
| Unresolved Questions | 2 |
| Water and Ice | 3 |

## Checks performed

- Parsed every line of the knowledge and QA JSONL files and checked required fields.
- Confirmed each QA record has one user message, one assistant message, a source title, and a source URL.
- Compared normalized questions across all three splits; found no exact duplicates.
- Reviewed the set for obvious near-duplicate question pairs and unsupported prompts; no near-duplicates were identified in this starter set.
- Checked that the split contains 32 train, 7 validation, and 7 test records. The train/validation/test proportions are approximately 70/15/15.
- Added five questions requiring reasoning across multiple source records, with supporting provenance stored separately.
- Retained source sections and document IDs as separate QA metadata for auditability.

## Human review flags

Flagged knowledge record IDs: `mars_010`, `mars_013`, `mars_020`, `mars_021`, and `mars_023`. Six QA examples draw on these claims: two surface-feature measurement questions, one briny-water question, one potential-biosignature question, and two human-exploration questions based on the dated presentation.

1. **2025 Perseverance potential-biosignature claim:** confirm wording and interpretation against the peer-reviewed paper and subsequent publications before using this item for high-confidence training. NASA's page calls the finding a potential biosignature, not evidence that establishes life.
2. **Briny slope-flow description:** the Mars facts page describes seasonal briny water flows. Review against primary and later research before treating active surface brines as settled; keep the claim attributed to the page.
3. **Mars surface feature measurements:** Olympus Mons base-to-summit height and Valles Marineris dimensions can vary with measurement definitions. Keep values source-attributed and check technical references if precision matters.
4. **Mission status:** the Mars Exploration Program page lists MAVEN as 2013-2026 and other missions as ongoing. Verify current mission status and dates at each dataset release.
5. **Human exploration report:** the NASA Technical Reports Server presentation is from 2013. Use it only as a dated list of challenges, not as current policy, requirements, or risk standards.

## Known limitations

- This is a 46-example starter set, not the requested approximate 300-example target. The reviewed source material was not broad enough to support 300 varied examples without repetition or additional source review.
- The knowledge records summarize accessible NASA pages; they are not exhaustive extractions. Some pages are dynamic and have no clear publication date.
- The NASA Technical Reports Server document is an older presentation. No dedicated, current NASA human-spaceflight medical or habitat standard was independently reviewed.
- Peer-reviewed papers, NASA Planetary Data System files, and source PDFs beyond the cited human-missions presentation were not independently analyzed. NASA overview pages sometimes summarize those materials.
- Numeric values may use different conventions or precision across sources. Where a source-specific value is provided, it should remain attributed rather than silently reconciled.
- Topic balance is limited by source coverage. Some topics have only one to three questions.
- The split is appropriate only as an initial working split. For a larger set, create semantic duplicate clusters first, assign whole clusters to partitions, and keep a saved split manifest.
- The 2025 potential-biosignature result and dynamic mission-status information may be superseded. Refresh these before training or publication.
